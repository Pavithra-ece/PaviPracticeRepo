package TestNGPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNGDataProvider2 {
	
	WebDriver driver;
	@DataProvider(name="daPr")
	public Object [][] dpmethod()
	{
		return new Object[][]
				{
			{"Pavi","Rahul","Gobi"},{"Pavi","Craj","cbe"},{"Priya","Pavi","chennai"}
				};
	}
	
	@Test(dataProvider="daPr")
	public void execute(String fname,String lname,String address)
	{
		driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(fname);
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lname);
		driver.findElement(By.xpath("//textarea[@class='form-control ng-pristine ng-untouched ng-valid']")).sendKeys(address);
		driver.quit();
	}

}
