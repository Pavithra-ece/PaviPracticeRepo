package TestNGPractice;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(value=TestNGPractice.ITestListenerImplementation.class)

public class ITestListener {
	
	
	
	@Test
	public void run()
	{
		ITestListenerInitializeWebDriver.initializeDriver().get("https://www.google.com");
		String Title=ITestListenerInitializeWebDriver.initializeDriver().getTitle();
		//Assert.assertEquals(Title, "Google123");
		Assert.assertEquals(Title, "Google");
	}

}
