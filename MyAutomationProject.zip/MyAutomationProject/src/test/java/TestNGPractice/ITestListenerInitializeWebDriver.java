package TestNGPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ITestListenerInitializeWebDriver {
	
	public static WebDriver driver=new ChromeDriver();
	
	public static WebDriver initializeDriver()
	{
		
		return driver;
	}

}
