package TestNGPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNGDataProvider1 {
	
	WebDriver driver;
	@DataProvider(name="dp")
	public Object [][] dpmethod()
	{
		return new Object [][]
				{
					{"Java"}, {"Selenium"}, {"Playwright"}
				};
	}
	
	
	@Test(dataProvider="dp")

    public void test(String x)
    {
		driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		
		WebElement ele=driver.findElement(By.xpath("//textarea[@class='gLFyf']"));
		ele.sendKeys(x);
		
		ele.sendKeys(Keys.ENTER);
		
		driver.quit();
		
		
		
    }
	

}
