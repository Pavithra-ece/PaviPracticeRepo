package TestNGPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNGCrossBrowser {
	
	
	public static WebDriver driver;
	
	@Parameters("browser")
	@BeforeMethod
	public void run(String browser)
	{
		if(browser.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
		}
		else if(browser.equalsIgnoreCase("Edge"))
		{
			driver=new EdgeDriver();
		}
	}
	
	@Test
	public void run1()
	{
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		String Title=driver.getTitle();
		Assert.assertEquals(Title, "Google");
	}
	
	
	
	

}
