package TestNGPractice;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ITestListenerImplementation implements ITestListener {
	
	

	@Override
	public void onTestStart(ITestResult result) {
		
		System.out.println("Test Started");
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		
		System.out.println("Test successful");
		
	}

	@Override
	public void onTestFailure(ITestResult result) {
		
		System.out.println("Testcase Failed");
		System.out.println("Taking Screenshot");
		
		TakesScreenshot shot1=(TakesScreenshot)ITestListenerInitializeWebDriver.initializeDriver();
		File srcfile=shot1.getScreenshotAs(OutputType.FILE);
		File dstFile=new File("D:\\testFolder_screenshot\\Test1.png");
		try {
			FileUtils.copyFile(srcfile, dstFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		
	}

	@Override
	public void onTestFailedWithTimeout(ITestResult result) {
		
	}

	@Override
	public void onStart(ITestContext context) {
		
		
	}

	@Override
	public void onFinish(ITestContext context) {
		
	}

	
	

}
