package TestNGPractice;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class GroupsPractice {

	@Test(groups="smoke")
	public void test1()
	{
		System.out.println("Smoke Testing-1");
	}
	@Test(groups="sanity")
	public void test2()
	{
		System.out.println("Sanity Testing-1");
	}
	@Test(groups="smoke")
	public void test3()
	{
		System.out.println("Smoke Testing-2");
	}
	@Test(groups="regression")
	public void test4()
	{
		System.out.println("Regression Testing-1");
		Reporter.log("Testcases are passed");
	}
	

}
