package TestNGPractice;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryAnalyzer1 implements IRetryAnalyzer

//automatically implements the method

{
	int retrylimit=4;
	int count=0;
	
	public boolean retry(ITestResult result) 
	{
		
		
		
		if(count<retrylimit)
		{
			count++;
			return true;
		}
		
		return false;
	}

}
