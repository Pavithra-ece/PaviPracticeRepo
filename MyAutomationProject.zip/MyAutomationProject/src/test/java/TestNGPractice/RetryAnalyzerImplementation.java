package TestNGPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;


public class RetryAnalyzerImplementation {
	
	@Test(retryAnalyzer=TestNGPractice.RetryAnalyzer1.class)
	
	public void test()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String Title=driver.getTitle();
		Assert.assertEquals(Title,"Google123");
		
	}

}
