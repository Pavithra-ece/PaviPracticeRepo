package TestNGPractice;

import org.testng.annotations.Test;

public class Priority {

	

	@Test(priority=0)
	public void A()
	{
		System.out.println("0");
	}
	@Test(priority=2)
	public void B()
	{
		System.out.println("2-positive");
	}
	@Test(priority='a')
	public void F()
	{
		System.out.println("small alphabet=a");
	}
	@Test
	public void C()
	{
		System.out.println("no priority=C");
	}
	@Test(priority=-4)
	public void D()
	{
		System.out.println("Negative=D");
	}
	@Test
	public void Call()
	{
		System.out.println("no priority=Call");
	}
	@Test(priority=-4)
	public void Doll()
	
	{
		System.out.println("Negative=Doll");
	}
	

}
