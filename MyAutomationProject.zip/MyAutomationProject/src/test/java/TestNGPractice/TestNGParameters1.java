package TestNGPractice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNGParameters1 {
	
	@Test
	@Parameters({"a","b","c"})
	public void sum(int x,int y,int z)
	{
		int r=x+y+z;
		System.out.println(r);
	}
	
	@Test
	@Parameters({"a","b"})
	public void sum(int x,int y)
	{
		int s=x+y;
		System.out.println(s);
	}
	@Test
	@Parameters({"a","b"})
	public void diff(int x,int y)
	{
		int d=x-y;
		System.out.println(d);
	}
	
	@Test
	@Parameters({"a","b","c"})
	public void multi(int x,int y, int z)
	{
		int m=x*y*z;
		System.out.println(m);
	}
	
	


}
