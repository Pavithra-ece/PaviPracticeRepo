package TestNGPractice;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Annotations {
	
	@BeforeSuite
	public void A()
	{
		System.out.println("BeforeSuite");
	}
	@AfterSuite
	public void B()
	{
		System.out.println("AfterSuite");
	}
	@BeforeTest
	public void C()
	{
		System.out.println("AfterTest");
	}
	@AfterTest
	public void D()
	{
		System.out.println("AfterTest");
	}
	@BeforeClass
	public void E()
	{
		System.out.println("BeforeClass");
	}
	@AfterClass
	public void F()
	{
		System.out.println("AfterClass");
	}
	@BeforeMethod
	public void G()
	{
		System.out.println("BeforeMEthod");
	}
	@AfterMethod

	public void H()
	{
		System.out.println("AfterMethod");
	}
	@Test
	public void test1()
	{
		System.out.println("Test1");
	}
	

}
