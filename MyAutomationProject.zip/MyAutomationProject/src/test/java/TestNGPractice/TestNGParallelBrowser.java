package TestNGPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNGParallelBrowser {
	
	public WebDriver driver;
	
	@Test
	public void run1()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
	}
	@Test
	public void run2()
	{
		driver=new ChromeDriver();
		driver.get("https://www.instagram.com");
		driver.manage().window().maximize();
		
	}
	@Test
	public void run3()
	{
		driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
	}
	@Test
	public void run4()
	{
		driver=new ChromeDriver();
		driver.get("https://www.firstcry.com");
		driver.manage().window().maximize();
		
	}
	@Test
	public void run5()
	{
		driver=new ChromeDriver();
		driver.get("https://www.amazon.com");
		driver.manage().window().maximize();
		
	}

}
