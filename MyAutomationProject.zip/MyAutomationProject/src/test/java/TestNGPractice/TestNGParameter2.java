package TestNGPractice;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class TestNGParameter2 {
	
	@Test
	@Parameters({"a","c"})
	public void sum(int p,int q)
	{
		int s=p+q;
		System.out.println("different class" + s);
	}

}
