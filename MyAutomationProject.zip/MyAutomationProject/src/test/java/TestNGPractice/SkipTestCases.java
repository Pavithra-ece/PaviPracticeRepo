package TestNGPractice;

import org.testng.annotations.Test;

public class SkipTestCases {
	
	@Test
	public void test1()
	{
		System.out.println("Test1");
	}
	
	// this method will be skipped 

	@Test(enabled=false)
	public void test2()
	{
		System.out.println("Test2");
	}
	@Test
	public void test3()
	{
		System.out.println("Test3");
	}
	@Test
	public void test4()
	{
		System.out.println("Test4");
	}
	@Test
	public void test5()
	{
		System.out.println("Test5");
	}


}
