package Stepdefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	
	WebDriver driver;
	@Before
	public void beforeTest()
	{
		System.out.println("I am executed Before test");
	}
	@After
	public void afterTest()
	{
		System.out.println("I am executed After test");
	}
	
	@Before("@smoke")
	public void beforeTestTag()
	{
		System.out.println("I am executed Before test-smoke");
	}
	@After("@smoke")
	public void afterTestTag()
	{
		System.out.println("I am executed After test-smoke");
	}
	
	
	
	@Given("user open the demo app")
	public void user_open_the_demo_app() {
		
		System.out.println("user opens the demo app");
	    
	}

	@Given("User enters the name")
	public void user_enters_the_name() {
		System.out.println("user enters the uname");
	   
	}

	@Given("user enters the password")
	public void user_enters_the_password() {
		System.out.println("user enters the pwd");
	    
	}

	@When("user clicks on the login button")
	public void user_clicks_on_the_login_button() {
		
		System.out.println("user clicks on login");
	   
	}

	@Then("user navigated to the home page")
	public void user_navigated_to_the_home_page() {
		System.out.println("user navigated to the home page");
		   
	}
	@Given("User enters the name as {string}")
	public void user_enters_the_name_as(String string) {
	    
	}

	@Given("user enters the password as {string}")
	public void user_enters_the_password_as(String string) {
	    
	}
	
	@Then("user search a cosmetic item")
	public void user_search_a_cosmetic_item() {
	    
	}

	@Then("user click on the item")
	public void user_click_on_the_item() {
	    
	}

	@Then("user adds the selected item to the cart")
	public void user_adds_the_selected_item_to_the_cart() {
	   
	}

	
	@Then("user search a electronic item")
	public void user_search_a_electronic_item() {
	    
	}

	@Then("user search a lifestyle item")
	public void user_search_a_lifestyle_item() {
	   
	}
	
	@Given("user opens the application form in the bowser")
	public void user_opens_the_application_form_in_the_bowser() {
		
		driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
	   
	}

	@Given("user enters the below details")
	public void user_enters_the_below_details(io.cucumber.datatable.DataTable dataTable) {
		
		List<List<String>> data=dataTable.asLists(String.class);
		
		
		
		driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(data.get(1).get(0));
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(data.get(1).get(1));
		
		driver.findElement(By.xpath("//textarea[@class='form-control ng-pristine ng-untouched ng-valid']")).sendKeys(data.get(1).get(2));
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys(data.get(1).get(3));
		
	   
	}


}
