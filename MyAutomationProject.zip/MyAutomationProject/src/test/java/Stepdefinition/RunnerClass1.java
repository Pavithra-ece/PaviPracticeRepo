package Stepdefinition;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/java/MyFeatureFiles",
    glue = "Stepdefinition",
    tags="@smoke"
   
)




public class RunnerClass1 {
	
	

}
