Feature: Validate the form with required fields

  Scenario: entering the required fields
    Given user opens the application form in the bowser
    And user enters the below details
      | fullname | lastname | Address   | emailaddress   |
      | pavi     | craj     | Tamilnadu | abcd@gmail.com |
