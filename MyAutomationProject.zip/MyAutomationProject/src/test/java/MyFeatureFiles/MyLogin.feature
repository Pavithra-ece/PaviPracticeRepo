Feature: Login functionality of the Application

  Scenario: Validate the login functionality with correct credentials
    Given user open the demo app
    And User enters the name
    And user enters the password
    When user clicks on the login button
    Then user navigated to the home page
    
@smoke
  Scenario Outline: Validate the login functionality with correct credentials
    Given user open the demo app
    And User enters the name as "username"
    And user enters the password as "password"
    When user clicks on the login button
    Then user navigated to the home page

    Examples: 
      | username | password    |
      | priya    | abce@123    |
      | pavi     | abcd@1232   |
      | priya    | abc@123jkak |
