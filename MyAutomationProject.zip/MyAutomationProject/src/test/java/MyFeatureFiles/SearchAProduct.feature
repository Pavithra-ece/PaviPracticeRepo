Feature: Search a Product and Add to Cart Functionality

  Background: 
    Given user open the demo app
    And User enters the name
    And user enters the password
    When user clicks on the login button
    Then user navigated to the home page
@smoke
  Scenario: Validate the add to cart functionality
    And user search a cosmetic item
    And user click on the item
    And user adds the selected item to the cart

  Scenario: Validate the add to cart functionality
    And user search a electronic item
    And user click on the item
    And user adds the selected item to the cart

  Scenario: Validate the add to cart functionality
    And user search a lifestyle item
    And user click on the item
    And user adds the selected item to the cart
