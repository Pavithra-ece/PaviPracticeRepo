package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseHOver {

	public static void main(String[] args) {
		
		
			
	    WebDriver driver=new ChromeDriver();
		driver.get("https://www.myntra.com/");
		driver.manage().window().maximize();
		
	    WebElement ele=driver.findElement(By.xpath("//a[@data-group='women']"));
	    
	    Actions act=new Actions(driver);
	    act.moveToElement(ele).build().perform();
		
		

	}

}
