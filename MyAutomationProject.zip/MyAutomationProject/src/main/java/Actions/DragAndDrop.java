package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Static.html");
		driver.manage().window().maximize();
		
		Thread.sleep(3000);
		
		WebElement place1=driver.findElement(By.xpath("//img[@id='angular']"));
		WebElement place2=driver.findElement(By.xpath("//div[@id='droparea']"));
		
		Actions act=new Actions(driver);
		act.dragAndDrop(place1, place2).build().perform();
	}

}
