package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CopyAndPasteKeyBoard {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		driver.manage().window().maximize();
		
		//driver.findElement(By.xpath("//input[@id='userName']")).sendKeys("Pavithra Chidambararaj");
		//driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys("pavithra222cp@gmail.com");
		driver.findElement(By.xpath("//input[@name='firstname']")).sendKeys("Pavithra");
		
		Actions act=new Actions(driver);
		
		//select the content
		
		act.keyDown(Keys.CONTROL);
		act.sendKeys("a");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		//copy the content
		act.keyDown(Keys.CONTROL);
		act.sendKeys("c");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		
		//give tab to move to permanent address textbox
		
		act.keyDown(Keys.TAB);
		act.keyUp(Keys.TAB);
		act.build().perform();
		
		//paste the content
		act.keyDown(Keys.CONTROL).sendKeys("v");
		act.keyUp(Keys.CONTROL);
		act.build().perform();
		

	}

}
