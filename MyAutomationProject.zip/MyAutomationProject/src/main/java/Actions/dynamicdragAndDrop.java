package Actions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class dynamicdragAndDrop {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		
		WebElement frame=driver.findElement(By.xpath("//iframe[@src='/resources/demos/droppable/default.html']"));
		
		driver.switchTo().frame(frame);
		
		WebElement srcplace1=driver.findElement(By.xpath("//div[@id='draggable']"));
		WebElement destplace2=driver.findElement(By.xpath("//div[@id='droppable']"));
		
		Actions act=new Actions(driver);
		act.dragAndDrop(srcplace1, destplace2).build().perform();
		

	}

}
