package BasicCommands;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class browserCommandsEx1 {

	public static void main(String[] args) {

		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		
		String Title=driver.getTitle();
		System.out.println("The page Title is "+Title);
		
		
		String PageSource=driver.getPageSource();
		System.out.println("The PageSource is "+PageSource);
		
		//String CurrentUrl=driver.getCurrentUrl();
		//System.out.println("The Current URL is "+CurrentUrl);
		
		driver.close();//closes all the windows open which are automated
		
		driver.quit();//closes only the window which is open. 
		
		

	}

}
