package BasicCommands;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

//1.	Launch a new Chrome browser.
//2.	Open Shop.DemoQA.com
//3.	Get Page Title name and Title length
//4.	Print Page Title and Title length on the Eclipse Console.
//5.	Get Page URL and verify if it is a correct page opened
//6.	Get Page Source (HTML Source code) and Page Source length
//7.	Print Page Length on Eclipse Console.
//8.	Close the Browser.


public class Test1 {

	public static void main(String[] args) {
		
        WebDriver driver=new ChromeDriver();
        
        String URL1="https://demoqa.com";
		
		driver.get(URL1);
		
		String PageTitleName=driver.getTitle();
		System.out.println("The Page Title is "+PageTitleName);
		
		int PageTitleLength=driver.getTitle().length();
		System.out.println("The Length of the Page Title is "+PageTitleLength);
		
		String CurrentURL=driver.getCurrentUrl();
		
		if(CurrentURL.equals(URL1))
		{
			System.out.println("The Page is correctly opened");
		}
		else
		{
			System.out.println("The Page is incorrectly opened");
		}
		
		System.out.println("The current url is "+CurrentURL);
		System.out.println("The url is "+URL1);
		
		String PageSource=driver.getPageSource();
		System.out.println("The PageSource is "+PageSource);
		
		int PageSourceLength=driver.getPageSource().length();
		System.out.println("The length of the PageSOurce is "+PageSourceLength);
		
		driver.close();
		

	}

}
