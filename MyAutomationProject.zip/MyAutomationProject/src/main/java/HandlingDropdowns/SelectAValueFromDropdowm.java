package HandlingDropdowns;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectAValueFromDropdowm {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		
		WebElement dropdownState=driver.findElement(By.name("state"));
		
		if(dropdownState.isDisplayed()==true && dropdownState.isEnabled()==true)
		{
			Select oselect=new Select(dropdownState);
			
			//oselect.selectByValue("Uttar Pradesh");
			
			//oselect.selectByVisibleText("Rajasthan");
			
			oselect.selectByIndex(2);
			
			
		}
		
		
		
	}

}
