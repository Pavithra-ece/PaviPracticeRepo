package HandlingDropdowns;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MultipleSelectDropdownValues {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/select-menu");
		driver.manage().window().maximize();
		
		WebElement ele=driver.findElement(By.id("cars"));
		
		Select oselect=new Select(ele);
		
		if(oselect.isMultiple()==true)
		{
			oselect.selectByIndex(0);
			oselect.selectByIndex(3);
			
		}
		//Thread.sleep(3000);
		//oselect.deselectAll();
		//oselect.deselectByIndex(0);
		
		
		//How to get the text of the firstselected option
		
		WebElement option1=oselect.getFirstSelectedOption();
		System.out.println("The first selected option is "+option1.getText());
		
		//How to get the text of all the selected options
		
		List<WebElement> AllOptions=oselect.getAllSelectedOptions();
		
		for(int i=0;i<AllOptions.size();i++)
		{
			
			System.out.println(AllOptions.get(i).getText());
		}
		
		
	}

}
