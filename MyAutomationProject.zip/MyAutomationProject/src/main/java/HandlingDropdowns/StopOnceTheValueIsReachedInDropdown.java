package HandlingDropdowns;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class StopOnceTheValueIsReachedInDropdown {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		
		WebElement dropdownCountry=driver.findElement(By.name("city"));
		
		if(dropdownCountry.isDisplayed()==true && dropdownCountry.isEnabled()==true)
		{
			Select oselect=new Select(dropdownCountry);
			List<WebElement> li=oselect.getOptions();
			
			for(int i=0;i<li.size();i++)
			{
				String dropdownvalue=li.get(i).getText();
				System.out.println(dropdownvalue);
				
				if(dropdownvalue.equalsIgnoreCase("Lucknow"))
				{
					System.out.println("Expected value is reached");
					break;
				}
			}
			
			
			
		}
		
		

	}

}
