package HandlingDropdowns;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class DisplayingMultipleValuesAvailableInDropdown {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		driver.manage().window().maximize();
		
		WebElement dropdownState=driver.findElement(By.name("state"));
		
		if(dropdownState.isDisplayed()==true && dropdownState.isEnabled()==true)
		{
			Select oselect=new Select(dropdownState);
			
			List<WebElement> li=oselect.getOptions();
			
			//getOptions() is a method used to get all the values from the dropdown
			//to display we have to iterate till the size of the dropdown.
			//to get the value of the dropdown we have use getText() method.
			
			for(int i=0;i<li.size();i++)
			{
				String value=li.get(i).getText();
				System.out.println(value);
			}
			
			
		}

	}

}
