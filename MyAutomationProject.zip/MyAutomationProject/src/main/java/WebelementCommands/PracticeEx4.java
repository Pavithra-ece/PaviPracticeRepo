package WebelementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeEx4 {

	public static void main(String[] args) {
		
       WebDriver driver=new ChromeDriver();
		
		driver.get("https://the-internet.herokuapp.com/dynamic_loading");
		
		driver.manage().window().maximize();
		
		driver.findElement(By.linkText("Example 1: Element on page that is hidden")).click();

	}

}
