package WebelementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeEx6 {

	public static void main(String[] args) {
	
        WebDriver driver=new ChromeDriver();
		
		driver.get("https://demoqa.com/automation-practice-form");
		
		driver.manage().window().maximize();
		
		WebElement textbox=driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		
		//getText()
		//getAttribute("Attributename")
		//getTagName
		//getSize()-----------Dimension------Height width
		//getLocation()---------Point------------ x y
		
		if(textbox.isDisplayed()==true && textbox.isEnabled()==true)
		{
			String text=textbox.getText();
			System.out.println("The textValue is "+text);
			
			String Attributename=textbox.getAttribute("id");
			System.out.println("The Attribute value of id(Attribute) is "+Attributename);
			
			String Tagname=textbox.getTagName();
			System.out.println("The TagName is "+Tagname);
			
			Dimension d=textbox.getSize();
			System.out.println("The Dimension is "+ "Height= "+ d.height + " Width= "+ d.width);
			
			Point p=textbox.getLocation();
			System.out.println("The Location is "+ "x= "+ p.x + " y= "+ p.y);
			
		}
		
	
		
		
	}

}
