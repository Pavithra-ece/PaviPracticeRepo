package WebelementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeEx5 {

	public static void main(String[] args) {
		
        WebDriver driver=new ChromeDriver();
		
		driver.get("https://the-internet.herokuapp.com/checkboxes");
		
		driver.manage().window().maximize();
		
		WebElement checkbox1=driver.findElement(By.xpath("(//input[@type='checkbox'])[1]"));
		
		if(checkbox1.isSelected()==true)
		{
		
		System.out.println("Enabled");
		}
		else
		{
			System.out.println("Not enabled");
		}
		WebElement checkbox2=driver.findElement(By.xpath("(//input[@type='checkbox'])[2]"));
		
		boolean status=checkbox2.isSelected();



		

}
}
