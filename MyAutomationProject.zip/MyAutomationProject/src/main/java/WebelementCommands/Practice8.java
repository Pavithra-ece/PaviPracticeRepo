package WebelementCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Practice8 {

	public static void main(String[] args) {
	
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
	   driver.findElement(By.cssSelector("[type='text'][placeholder='First Name']")).sendKeys("Pavithra");
	   driver.findElement(By.cssSelector("[ng-model$='ne']")).sendKeys("9597613526");
	   
		
		

	}

}
