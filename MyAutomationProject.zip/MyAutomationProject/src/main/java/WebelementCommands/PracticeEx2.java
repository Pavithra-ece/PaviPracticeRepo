package WebelementCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeEx2 {

	public static void main(String[] args) {
		
        WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
		
		driver.manage().window().maximize();
		
	    List<WebElement> li=driver.findElements(By.xpath("//input"));
		
		
	    
	
	    
	    //findelements give all the results of the give tagname-input
	    
	    int taglistresult=li.size();
	    
	    System.out.println(taglistresult);
		
		

	}

}
