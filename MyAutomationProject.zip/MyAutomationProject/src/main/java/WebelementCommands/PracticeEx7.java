package WebelementCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PracticeEx7 {

	public static void main(String[] args) {
		
	//Interview question-print all the hyperlinks available in the page
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().window().maximize();
		
		List<WebElement> li=driver.findElements(By.tagName("div"));
		
		for(int i=0;i<li.size();i++)
		{
			System.out.println(li.get(i).getText());
		}
		
		
		

	}

}
