package HandlingWindows;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Takingscreenshot {

	public static void main(String[] args) throws IOException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/FileUpload.html");
		driver.manage().window().maximize();
		
		TakesScreenshot shot1=(TakesScreenshot)driver;
		
		//storing the screenshot in file type
		
		File srcfile=shot1.getScreenshotAs(OutputType.FILE);
		File dstfile=new File("D:\\testFolder_screenshot\\mytest.png");
		FileUtils.copyDirectory(srcfile, dstfile);
		
		
		
		

	}

}
