package HandlingWindows;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class twowindows {

	public static void main(String[] args) {
		
		
	    WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();

		String parentWindow=driver.getWindowHandle();
		System.out.println("The window id id "+parentWindow);
		
		
		
		//we will get the same window id of the page 1 as the control is in page1
//		String page2=driver.getWindowHandle();
//		System.out.println("The window id id "+page2);
		
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Set<String> windowIDs=driver.getWindowHandles();
		
		

		
		System.out.println("The window ids are "+windowIDs);
		
		Iterator<String> itr=windowIDs.iterator();
				
				while(itr.hasNext())
				{
					String childWindow=itr.next();
					if(!parentWindow.equals(childWindow))
					{
						driver.switchTo().window(childWindow);
						String title=driver.getTitle();
						System.out.println("The title of childwindow is "+title);
						//driver.findElement(By.xpath("//a[@href='/downloads']")).click();
						driver.switchTo().window(parentWindow);
						String title1=driver.getTitle();
						System.out.println("The title of firstwindow is "+title1);
						
					}
				}
		
		
		
	}

}
