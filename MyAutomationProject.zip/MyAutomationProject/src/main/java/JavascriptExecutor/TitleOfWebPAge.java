package JavascriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TitleOfWebPAge {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		String Title=(String)js.executeScript("return document.title;");
		
		System.out.println("The Title of the page is "+Title);
		

	}

}
