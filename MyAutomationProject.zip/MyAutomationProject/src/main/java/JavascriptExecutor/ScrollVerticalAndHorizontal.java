package JavascriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScrollVerticalAndHorizontal {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		//scrolling downwards
		js.executeScript("window.scrollBy(0,4000)","");
		
		Thread.sleep(3000);
		
		//scrolling upwards
		js.executeScript("window.scrollBy(0,-1000)","");
		Thread.sleep(3000);
		
		//scrolling rightside
		js.executeScript("window.scrollBy(1000,0)","");
		
		//scrollinf leftside
		js.executeScript("window.scrollBy(-1000,0)","");
		

	}

}
