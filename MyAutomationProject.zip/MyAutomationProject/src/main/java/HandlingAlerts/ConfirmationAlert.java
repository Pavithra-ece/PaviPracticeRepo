package HandlingAlerts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ConfirmationAlert {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		//accept will click on ok
		
		driver.switchTo().alert().accept();
		
		String value=driver.findElement(By.xpath("//p[@id='demo']")).getText();
		System.out.println(value);
		
		//dismiss will click on dismiss();

		driver.navigate().refresh();
		
		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		
		driver.switchTo().alert().dismiss();
		
		String value1=driver.findElement(By.xpath("//p[@id='demo']")).getText();
		System.out.println(value1);
		

	}

}
