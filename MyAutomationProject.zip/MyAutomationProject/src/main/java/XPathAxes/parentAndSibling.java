package XPathAxes;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class parentAndSibling {

	public static void main(String[] args) {
		

		WebDriver driver=new ChromeDriver();
		driver.get("https://www.nseindia.com/market-data/live-equity-market");
		driver.manage().window().maximize();
		
		WebElement ele=driver.findElement(By.xpath("//*[text()='2,039.00']//parent::td//preceding-sibling::td//a[text()='SBILIFE']"));
		
	
		String value=ele.getText();
		System.out.println("The value is "+value);
		
		
	}

}

